#include<iostream>
using namespace std;
int main()
{
	float a,b,c;
	cout<<"\nEnter the a:";
	cin>>a;
	cout<<"\nEnter the b:";
	cin>>b;
	cout<<"\nEnter the c:";
	cin>>c;
	
	if(a>b)
	{
		if(a>c)
		{
			cout<<"\n"<<a<<"is larger";
		}
		else
		{
			cout<<"\n"<<c<<"is larger";
		}
	}
	else
	{
		if(b>c)
		{
			cout<<"\n"<<b<<"is larger";
		}
		else{
			cout<<"\n"<<c<<"is larger";
		}
	}
	
}
