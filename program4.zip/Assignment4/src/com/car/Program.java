package com.car;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calulatedistance d1=new Calulatedistance();
		d1.accept();
		d1.calculate();
		

	}

}


