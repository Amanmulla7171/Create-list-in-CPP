package com.car;

import java.util.Scanner;

public class Calulatedistance {

	
		// TODO Auto-generated method stub
		double dailymile;
		double costofgas;
		double average;
		double parking;
		double tolls;
		
		
		public void accept() {
			Scanner sc = new Scanner(System.in); 
			System.out.println("Enter Total miles driven per day:");
			this.dailymile=sc.nextDouble();
			System.out.println("Enter Cost per gallon of gasoline:");
			this.costofgas=sc.nextDouble();
			System.out.println("Enter Average miles per gallon:");
			this.average=sc.nextDouble();
			System.out.println("Enter Parking fees per day:");
			this.parking=sc.nextDouble();
			System.out.println("Enter Tolls per day:");
			this.tolls=sc.nextDouble();
			
			
		}
		public void calculate() {
			double fuel=this.dailymile/this.average;
			double fuelcost=fuel*this.costofgas;
			double Totalcostperday=fuelcost+this.parking+this.tolls;
			
			System.out.println("The total cost per day is :₹%.2f%n"+Totalcostperday);
		}
		

	}


