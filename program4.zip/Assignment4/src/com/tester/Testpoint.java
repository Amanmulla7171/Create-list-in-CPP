package com.tester;
import java.util.Scanner;

public class Testpoint {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter how many points you want to plot: ");
        int num = sc.nextInt();
        Point2d[] points = new Point2d[num];

        for (int i = 0; i < num; i++) {
            System.out.print("Enter X coordinate for point " + i + ": ");
            double x = sc.nextDouble();
            System.out.print("Enter Y coordinate for point " + i + ": ");
            double y = sc.nextDouble();
            points[i] = new Point2d(x, y);
        }

        int choice;
        do {
            System.out.println("\n----- Menu -----");
            System.out.println("1. Display details of a specific point");
            System.out.println("2. Display x, y co-ordinates of all points");
            System.out.println("3. Display distance between specified points");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter index of the point: ");
                    int index = sc.nextInt();
                    if (index >= 0 && index < points.length) {
                        System.out.println("Point: " + points[index].getDetails());
                    } else {
                        System.out.println("Invalid index, pls retry!");
                    }
                    break;

                case 2:
                    System.out.println("All Points:");
                    for (Point2d p : points) {
                        System.out.println(p.getDetails());
                    }
                    break;

                case 3:
                    System.out.print("Enter index of start point: ");
                    int i1 = sc.nextInt();
                    System.out.print("Enter index of end point: ");
                    int i2 = sc.nextInt();
                    if (i1 >= 0 && i1 < points.length && i2 >= 0 && i2 < points.length) {
                        if (points[i1].isEqual(points[i2])) {
                            System.out.println("Both points are at the same location.");
                        } else {
                            double distance = points[i1].calculateDistance(points[i2]);
                            System.out.println("Distance between points: " + distance);
                        }
                    } else {
                        System.out.println(" Invalid indices, please retry!");
                    }
                    break;

                case 0:
                    System.out.println("Exiting program. ");
                    
                    break;

                default:
                    System.out.println(" Invalid choice, please select again.");
            }

        } while (choice != 0);

        sc.close();
    }
}

