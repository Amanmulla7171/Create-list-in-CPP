package com.tester;



public class Point2d {

	 private double x;
	 private double y;

	    public Point2d(double x, double y) {
	        this.x = x;
	        this.y = y;
	    }

	    public String getDetails() {
	        return "Point(" + x + ", " + y + ")";
	    }

	    public boolean isEqual(Point2d other) {
	        return this.x == other.x && this.y == other.y;
	    }

	    public double calculateDistance(Point2d other) {
	        return Math.sqrt(Math.pow(this.x - other.x, 2) + Math.pow(this.y - other.y, 2));
	    }
}
